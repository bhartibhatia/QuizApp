package com.example.android.mainquiz;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

public class JavaActivity extends AppCompatActivity {
    //question1
    EditText ques1_edit;
    //question2
    RadioButton ques_one_first_button;
    //question3
    CheckBox ques_three_checkbox_one;
    CheckBox ques_three_checkbox_two;
    //question4
    RadioButton ques_four_first_button;
    //question5
    RadioButton ques_five_third_button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_java);
    }
    public void submitAnswers(View view) {
        CharSequence resultsDisplay;
        int answer1_score;
        int answer2_score;
        int answer3_score;
        int answer4_score;
        int answer5_score;
        int final_score;
       // ---------------------------------------------//
        //question1 Answer
       //-----------------------------------------------//
        String answer1;
        ques1_edit = (EditText) this.findViewById(R.id.ques1_edit);
        answer1 = ques1_edit.getText().toString().toLowerCase();
        if (answer1.equals("4")) {
            answer1_score = 1;
        } else {
            answer1_score = 0;
        }
        // ---------------------------------------------//
        //question2 Answer
        //----------------------------------------------//
        Boolean answer2;
        ques_one_first_button = (RadioButton) this.findViewById(R.id.ques_one_first_button);
        answer2 = ques_one_first_button.isChecked();
        if (answer2) {
            answer2_score = 1;
        } else {
            answer2_score = 0;
        }
        // ---------------------------------------------//
        //question3 Answer
        //----------------------------------------------//
        Boolean  answer3a;
        Boolean  answer3b;
        ques_three_checkbox_one = (CheckBox) this.findViewById(R.id. ques_three_checkbox_two);
        ques_three_checkbox_two= (CheckBox) this.findViewById(R.id. ques_three_checkbox_two);
        answer3a =  ques_three_checkbox_one.isChecked();
        answer3b =  ques_three_checkbox_two.isChecked();
        if (answer3a && !answer3b) {
            answer3_score = 1;
        } else {
            answer3_score = 0;
        }
        // ---------------------------------------------//
        //question4 Answer
        //----------------------------------------------//
        Boolean answer4;
        ques_four_first_button = (RadioButton) this.findViewById(R.id.ques_four_first_button);
        answer4 = ques_four_first_button.isChecked();
        if (answer4) {
            answer4_score = 1;
        } else {
            answer4_score = 0;
        }
        // ---------------------------------------------//
        //question5 Answer
        //----------------------------------------------//
        Boolean answer5;
        ques_five_third_button = (RadioButton) this.findViewById(R.id.ques_five_third_button);
        answer5 = ques_five_third_button.isChecked();
        if (answer5) {
            answer5_score = 1;
        } else {
            answer5_score = 0;
        }
        //-----------------------------------------------//
        // Final Score
        //----------------------------------------------//
        final_score = answer1_score + answer2_score + answer3_score + answer4_score + answer5_score;
        if (final_score == 5) {
            resultsDisplay = "Perfect! You scored 5 out of 5";
        } else {
            resultsDisplay = "Try again. You scored " + final_score + " out of 5";
        }

        Context context = getApplicationContext();
        int duration = Toast.LENGTH_LONG;
        Toast toast = Toast.makeText(context, resultsDisplay, duration);
        toast.setGravity(Gravity.CENTER, 0, 0);
        toast.show();
}

    public void backaction(View view) {
        Intent intent=new Intent(JavaActivity.this, SettingsActivity.class);
        startActivity(intent);
    }
}
