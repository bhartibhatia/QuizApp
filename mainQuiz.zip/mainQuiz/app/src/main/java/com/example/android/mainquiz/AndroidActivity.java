package com.example.android.mainquiz;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

public class AndroidActivity extends AppCompatActivity {
  //answer1//
    EditText and_edit_text;
    //answer2//
    RadioButton and_radio_answer_two_b;
    //answer3//
    RadioButton and_radio_answer_three_c;
    //answer4//
    RadioButton and_radio_answer_four_a;
    //answer5//
    RadioButton and_radio_answer_five_c;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_android);
    }

    public void submitAns(View view) {
        CharSequence resultsDisplay;
        int answer1_score;
        int answer2_score;
        int answer3_score;
        int answer4_score;
        int answer5_score;
        int final_score;
        // ---------------------------------------------//
        //question1 Answer
        //-----------------------------------------------//
        String ans1;
        and_edit_text = (EditText) this.findViewById(R.id.and_edit_text);
        ans1 = and_edit_text.getText().toString().toLowerCase();
        if (ans1.equals("Resources Files")) {
            answer1_score = 1;
        } else {
            answer1_score = 0;
        }
        // ---------------------------------------------//
        //question2 Answer
        //----------------------------------------------//
        Boolean ans2;
        and_radio_answer_two_b = (RadioButton) this.findViewById(R.id.and_radio_answer_two_b);
        ans2 = and_radio_answer_two_b.isChecked();
        if (ans2) {
            answer2_score = 1;
        } else {
            answer2_score = 0;
        }
        // ---------------------------------------------//
        //question3 Answer
        //----------------------------------------------//
        Boolean ans3;
        and_radio_answer_three_c = (RadioButton) this.findViewById(R.id.and_radio_answer_three_c);
        ans3 = and_radio_answer_three_c.isChecked();
        if (ans3) {
            answer3_score = 1;
        } else {
            answer3_score = 0;
        }
        // ---------------------------------------------//
        //question3 Answer
        //----------------------------------------------//
        Boolean ans4;
        and_radio_answer_four_a = (RadioButton) this.findViewById(R.id.and_radio_answer_four_a);
        ans4 = and_radio_answer_four_a.isChecked();
        if (ans4) {
            answer4_score = 1;
        } else {
            answer4_score = 0;
        }
        // ---------------------------------------------//
        //question3 Answer
        //----------------------------------------------//
        Boolean ans5;
        and_radio_answer_five_c = (RadioButton) this.findViewById(R.id.and_radio_answer_five_c);
        ans5 = and_radio_answer_five_c.isChecked();
        if (ans5) {
            answer5_score = 1;
        } else {
            answer5_score = 0;
        }
        //-----------------------------------------------//
        // Final Score
        //----------------------------------------------//
        final_score = answer1_score + answer2_score + answer3_score + answer4_score + answer5_score;
        if (final_score == 5) {
            resultsDisplay = "Perfect! You scored 5 out of 5";
        } else {
            resultsDisplay = "Try again. You scored " + final_score + " out of 5";
        }

        Context context = getApplicationContext();
        int duration = Toast.LENGTH_LONG;
        Toast toast = Toast.makeText(context, resultsDisplay, duration);
        toast.setGravity(Gravity.CENTER, 0, 0);
        toast.show();

    }

    public void backaction(View view) {
        Intent intent=new Intent(AndroidActivity.this, SettingsActivity.class);
        startActivity(intent);
    }
}
