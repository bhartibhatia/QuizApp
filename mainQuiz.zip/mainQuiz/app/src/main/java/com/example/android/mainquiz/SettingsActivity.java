package com.example.android.mainquiz;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class SettingsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
    }

    public void openandroid(View view) {
        Intent intent=new Intent(SettingsActivity.this, AndroidActivity.class);
        startActivity(intent);
    }

    public void openjava(View view) {
        Intent intent2 = new Intent(SettingsActivity.this, JavaActivity.class);
        startActivity(intent2);
    }

    public void opensetting(View view) {
        Intent intent3 = new Intent(SettingsActivity.this, ClosingActivity.class);
        startActivity(intent3);
    }

}
